﻿/****************************************************/
					INFORMATION
/****************************************************/

Ce plugin va permettre à vos clients de laisser un commentaire et de noter un produit.
Vous pourrez également gérer les commentaires (valider/supprimer) depuis le panel d'administration.

/****************************************************/
					INSTALLATION
/****************************************************/

Glissez simplement le répertoire commentaires dans le dossier "client/plugins/" de votre Thélia.
Vous pouvez aussi importer le plugin directement depuis Thélia dans "Configuration/gestion des plugins".
Activez ensuite le plugin depuis "Configuration/gestion des plugins" dans votre panel d'administration.
Pensez à glisser le dossier "notation" dans le dossier "_gfx" de votre template.

/****************************************************/
    EXEMPLE D'AJOUT D'UN COMMENTAIRE ET D'UNE NOTE
/****************************************************/

<form action="#URL" method="post">
	<input type="hidden" name="action" value="ajcommentaire" />
	<input type="hidden" name="commentaire_ref" value="#PRODUIT_REF" />
	<input type="hidden" name="ref" value="#PRODUIT_REF" />

	<p><label for="nom">Nom :</label><br /><input id="nom" type="text" name="commentaire_nom" /></p>
	<p><label for="message">Message :</label><br /><textarea id="message" name="commentaire_message"></textarea></p>
	<p>
		<label for="note">Note :</label><br />
		<select id="note" name="commentaire_note">
			<option value="5">5/5</option>
			<option value="4">4/5</option>
			<option value="3">3/5</option>
			<option value="2">2/5</option>
			<option value="1">1/5</option>
		</select>
	</p>
	<input type="submit" value="Envoyer"/>
</form>

/****************************************************/
				PARAMETRES D'ENTREE
/****************************************************/

ref => référence du produit
deb => debut
num => nombre de résultat
ordre => croissant | decroissant
nofiltre = true (permet d'afficher tous les commentaires ou seulement ceux qui ont été validés)
noboucle = true (évite que la boucle ne soit utilisée dans la classe afin de pouvoir utiliser les paramètres de sortie #NBRE et #MOYENNE)

/****************************************************/
				PARAMETRES DE SORTIE
/****************************************************/

#NOM => nom de la personne qui a posté un commentaire
#MESSAGE => contenu du commentaire
#NOTE => note du produit
#DATE => date du commentaire
#HEURE => heure du commentaire
#NBRE => nombre de résultat (seulement si noboucle est à true)
#MOYENNE => moyenne des notes (seulement si noboucle est à true)

/****************************************************/
	EXEMPLE D'UN AFFICHAGE PAR ORDRE DECROISSANT
/****************************************************/

<THELIA_comment type="COMMENTAIRES" ref="#PRODUIT_REF" ordre="decroissant">
	<p>#NOM le #DATE #HEURE - <img src="template/_gfx/notation/#NOTE.png" alt=""/><br />#MESSAGE</p>
</THELIA_comment>

/********************************************************************/
	EXEMPLE D'AFFICHAGE DE LA MOYENNE ET DU NOMBRE DE COMMENTAIRES
/********************************************************************/

<THELIA_COMMENTAIRES type="COMMENTAIRES" ref="#PRODUIT_REF" noboucle="true">
	<p><img src="template/_gfx/notation/#MOYENNE.png" alt=""/> - <a href="#commentaires">Voir les #NBRE commentaire(s)</a></p>
</THELIA_COMMENTAIRES>

/****************************************************/
					INFO
/****************************************************/

Ce plugin a été réalisé en suivant le tutoriel sur la création d'un plugin classique sur le site de Thélia.