Par défaut, la création de déclinaison applique celle-ci à l’ensemble des rubriques et produits du catalogue.
Dans certains cas, c’est le résultat attendu ;)
Mais quelquefois, il faut vite, vite tout modifier parce que le site est en ligne...

Ce plugin permet entre-autre de faire cette dernière opération en 1 clic. Sans doute que la capture d’écran permet d’éviter de trop longs discours ;)

Réalisé et partagé par Pixelsmill